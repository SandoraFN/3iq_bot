import pytz

OWNERS = []

bot_token = ''
database_url = ''
timezone_info = pytz.timezone('Europe/Moscow')

start_text = 'Главное меню: '
text_for_participation_in_comments_giveaways = 'Участвую'

