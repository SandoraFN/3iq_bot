# flake8: noqa
from aiogram_calendar.simple_calendar import calendar_callback as simple_cal_callback, SimpleCalendar
from aiogram_calendar.dialog_calendar import calendar_callback as dialog_cal_callback, DialogCalendar
